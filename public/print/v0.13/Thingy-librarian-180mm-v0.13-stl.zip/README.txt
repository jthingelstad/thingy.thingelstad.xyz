Thingy, librarian, 180 mm (v0.13)

Thingy in the pose of the original illustration, in his librarian coat and
with his original face, as one solid for printing in one colour. He stands
on his own oval base, 120 x 62 x 180 mm.

Made for a Bambu Lab P2S with a 0.4 mm nozzle:
  Printer: Bambu Lab P2S, 0.4 mm nozzle
  Filament: Bambu PLA Basic, one colour
  Process: 0.16mm High Quality @BBL P2S
  Supports: On: tree (auto), organic style, from the plate and on the model
  Infill: 12%
  Walls: 3
  Brim: Outer, 5 mm
  Orientation: Upright on his base, as the file comes

He has not been test-printed yet. Expect to check supports under the coat
hem and the head.

Thingy is by Jamie Thingelstad. This print model is licensed CC BY-NC 4.0:
print it, share it and change it, with credit, for non-commercial use.
https://creativecommons.org/licenses/by-nc/4.0/

https://thingy.thingelstad.xyz/print/
